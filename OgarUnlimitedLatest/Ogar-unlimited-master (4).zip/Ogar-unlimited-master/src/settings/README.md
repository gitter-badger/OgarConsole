## Settings
This is where the server configurations are put in
