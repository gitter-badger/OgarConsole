module.exports = function (gameServer, split) {
  gameServer.op = [];
  gameServer.oppname = [];
  gameServer.opc = [];
  gameServer.opname = [];
  console.log("Reset OP");
};
