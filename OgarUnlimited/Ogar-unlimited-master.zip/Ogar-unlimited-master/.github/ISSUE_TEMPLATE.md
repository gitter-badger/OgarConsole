Please read the faq in advance

Most common questions involve:

Why is there an error "cannot find module"
A: Do npm install after you cd into the repo
